package com.INGAtm.model;

public class City {

    String atmNumber;
    String city;
    String branch;
    
    private String Type;
    private String functionality;
    private String distance;
    private Address address;
    
    public City(String atmNumber, String city, String branch) {
		super();
		this.atmNumber = atmNumber;
		this.city = city;
		this.branch = branch;
	}


	public String getType() {
		return Type;
	}


	public void setType(String type) {
		Type = type;
	}


	public String getFunctionality() {
		return functionality;
	}


	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}


	public String getDistance() {
		return distance;
	}


	public void setDistance(String distance) {
		this.distance = distance;
	}


	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}


	public String getAtmNumber() {
		return atmNumber;
	}


	public void setAtmNumber(String atmNumber) {
		this.atmNumber = atmNumber;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getBranch() {
		return branch;
	}


	public void setBranch(String branch) {
		this.branch = branch;
	}

	

    
}
