package com.INGAtm.model;

import org.hibernate.validator.constraints.NotBlank;

public class SearchCriteria {

    @NotBlank(message = "City can't empty!")
    String city;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

    
}