package com.INGAtm.services;

import com.INGAtm.model.City;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SearchService {

    private List<City> atmList;


    public List<City> findATMByCity(String city) {

    	//Stream API - java8
        List<City> result = atmList.stream().filter(x -> x.getCity().equalsIgnoreCase(city)).collect(Collectors.toList());

        return result;

    }
    // Init some atmList for testing
    @PostConstruct
    private void iniDataForTesting() {

    	atmList = new ArrayList<City>();
    	
        
        City atmLst = new City("INGATM101", "Dutch", "Branch1");
        City atmLst2 = new City("INGATM102", "Dutch", "Branch5");
        City atmLst3 = new City("INGATM103", "Dutch", "Branch6");
        City atmLst4 = new City("INGATM104", "Dutch", "Branch2");
        City atmLst5 = new City("INGATM105", "Dutch", "Branch3");

        atmList.add(atmLst);
        atmList.add(atmLst2);
        atmList.add(atmLst3);
        atmList.add(atmLst4);
        atmList.add(atmLst5);
      

    }

}
