$(document).ready(function () {

    $("#search-form").submit(function (event) {

        //stop submit the form, we will post it manually.
        event.preventDefault();

        fire_ajax_submit();

    });

});

function fire_ajax_submit() {

    var search = {}
    search["city"] = $("#city").val();

    $("#btn-search").prop("disabled", true);

    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/api/search",
        data: JSON.stringify(search),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {

            var json = "<h4>ATM's in </h4><pre>"
                + JSON.stringify(data, null, 4) + "</pre>";
           
            var student = '';
            student += '<tr>'; 
            student += '<td>' +  
                'ATM NUMBER' + '</td>'; 
            
            student += '<td>' +  
            'CITY' + '</td>'; 
            
            student += '<td>' +  
            'BRANCH' + '</td>'; 
            
            student += '<tr>'; 
            
            $.each(data.result, function (idx, value) { 
            	//$('#AtmList-Container').html(value.atmNumber);
            	student += '<tr>'; 
                            student += '<td>' +  
                                value.atmNumber + '</td>'; 
  
                            student += '<td>' +  
                                value.city + '</td>'; 
  
                            student += '<td>' +  
                                value.branch + '</td>';
  
                            student += '</tr>'; 
            })
           
            $('#table-list').html(student);
            console.log("SUCCESS : ", data);
            $("#btn-search").prop("disabled", false);

        },
        error: function (e) {

            var json = "<h4>ATM's in </h4><pre>"
                + e.responseText + "</pre>";
            $('#AtmList-Container').html(json);

            console.log("ERROR : ", e);
            $("#btn-search").prop("disabled", false);

        }
    });

}